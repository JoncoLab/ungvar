<?php
/**
 * Created by PhpStorm.
 * User: Saladin
 * Date: 09.03.2017
 * Time: 21:36
 */

print_r($_POST);