<?php
$p = "\r\n";
$name = $_POST["name"];
$tel = $_POST["tel"];
$email = $_POST["email"];
$userMessage = $_POST["message"];
$subject = $_POST["subject"];
$to = 'feedback@ungvar.uz.ua, joncolab@gmail.com';
$message = $name . ' пише:' . $p;
$message .= $userMessage . $p . $p;
$message .= 'Його контактні дані:' . $p;
$message .= 'Електронна пошта - ' . $email . $p;
$message .= 'Мобільний телефон - ' . $tel;
$headers = 'From: ' . $name . ' <' . $email . '>; charset=utf-8';

mail($to, $subject, $message, $headers);
mail($email, 'Зворотній зв\'язок', 'Ваше звернення в службу підтримки успішно опрацьоване! Очікуйте на відповідь!', 'From: Ungvar Online <feedback@ungvar.uz.ua>; charset=utf-8');